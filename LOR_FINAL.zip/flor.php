<?php
session_start();
?><!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">


<style>
         .button {
         background-color: #1c87c9;
         border: none;
         width: 100px;
         color: white;
         padding: 8px 8px;
         text-align: center;
         text-decoration: none;
         display: inline-block;
         font-size: 10px;
         margin: 2px 2px;
         cursor: pointer;
         }
      </style>
</head>
<body>
<div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="faculty_home.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Home</a>

<a href="index.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>
<div id="page-wrapper">
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h1 class="page-head-line"><p style="text-align:center">LOR Acceptance</p>
</h1>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<p style="font-size: 15px;font-weight: bold;">List of Student Requests</p>
</div>
<div class="panel-body">
<div class="table-sorting table-responsive">
<table class="table table-striped table-bordered" id="tSortable22">
<thead>
<tr>
<th>ID</th>
<th>Name</th>
<th>email</th>
<th>University Details</th>
<th>Proof</th>
<th>Comments</th>
<th>Suggestions</th>
<th>Accept  or reject</th>
<th>LOR template 1</th>
<th>LOR template 2</th>
<th>Rejected file</th>
<th>Upload LOR</th>
<th>Send mail</th>
<th>Delete</th>
</tr>
</thead>
<tbody>
</tr>
<?php
 $id= $_SESSION["id"];
$db = mysqli_connect("localhost", "root", "", "proj");
if ($db->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{
$sql = "SELECT * FROM slor where  Faculty like '%$id%' ";
$result = mysqli_query($db, $sql); 
}


while($row =mysqli_fetch_assoc($result)) 
{ 
 

  echo ' <tr>'; 
  echo '<td>'.$row['Reg_no'].'</td>'; 
  echo '<td>'.$row['name'].'</td>'; 
  echo '<td>'.$row['email'].'</td>'; 
  echo '<td>'.$row['college'].'</td>'; 
  echo '<td><a href="'.$row['Location'].'" class="button">Download Proof</a></td>';
  echo '<td>'.$row['comments'].'</td>'; 
  echo '<td>'.$row['suggestion'].'</td>'; 
 
echo '<td>
<form method="POST" action="accept.php">
<a href="accept.php?Reg_no='.$row['Reg_no'].'&name='.$row['name'].'&email='.$row['email'].
'&college='.$row['college'].'&comments='.$row['comments'].'&fname='.$row['fname'].'" name="approved" class="button">Accept</a>

</form>
<form method="POST" action="reject.php">
<a href="reject.php?Reg_no='.$row['Reg_no'].'&name='.$row['name'].'&email='.$row['email'].
'&college='.$row['college'].'&comments='.$row['comments'].'&fname='.$row['fname'].'" name="rejected"  class="button">Reject</a>

</form>

</td>
<td>
<form method="POST" action="Lor1.php">
<a href="Lor1.php?Reg_no='.$row['Reg_no'].'&name='.$row['name'].'&email='.$row['email'].
'&college='.$row['college'].'&comments='.$row['comments'].'&fname='.$row['fname'].'" class="button">Lor1</a>

</form>
</td>
<td>
<form method="POST" action="Lor2.php">
<a href="Lor2.php?Reg_no='.$row['Reg_no'].'&name='.$row['name'].'&email='.$row['email'].
'&college='.$row['college'].'&comments='.$row['comments'].'&fname='.$row['fname'].'" class="button">Lor2</a>

</form>
</td>
<td>
<form method="POST" action="rejected.php">
<a href="rejected.php?Reg_no='.$row['Reg_no'].'&name='.$row['name'].'&email='.$row['email'].
'&college='.$row['college'].'&comments='.$row['comments'].'&fname='.$row['fname'].'" class="button">Rejection_file</a>

</form>
</td>
<td>
<form method="POST" action="uploadlor.php">
<a href="ulor.php"> <input name="submit" class="button" type="submit2" value="Upload Lor"> 
</form>

<td>
<form method="POST" action="mailfun.php">
<a href="mailfun.php?Reg_no='.$row['Reg_no'].'&name='.$row['name'].'&email='.$row['email'].
'&college='.$row['college'].'&comments='.$row['comments'].'&fname='.$row['fname'].'" class="button">Send Mail</a>

</form>
<td>
<form method="POST" action="delete.php">
<a href="delete.php?Reg_no='.$row['Reg_no'].'&name='.$row['name'].'&email='.$row['email'].
'&college='.$row['college'].'&comments='.$row['comments'].'&fname='.$row['fname'].'" class="button">Delete</a>

</form>
</td>
</tr>';

}

// <a href="accept.php?username=pooja&age=40



echo "</table>";

$db->close();
?>

</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</body>
</html>


