
<?php
session_start();
$id="";
$password="";
$errors =array();
$db=mysqli_connect('localhost','root','','proj') or die('could not connect to database');
//Login user
if(isset($_POST['login'])){
    $id=mysqli_real_escape_string($db,$_POST['id']);
    $password=mysqli_real_escape_string($db,$_POST['password']);
    if(empty($id)){
        array_push($errors,"id is required");}
    if(empty($password)){
        array_push($errors,"password is required");}
    if(count($errors)==0){
        $query="SELECT * FROM user WHERE id='$id' AND password='$password' ";
        $results=mysqli_query($db,$query);
        if(mysqli_num_rows($results)){
            $_SESSION["id"]=$id;
			$_SESSION["password"]=$password;
            $_SESSION["role"]=$type;
        header("location:student_home.php");} 
        else{

			array_push($errors,"please try again");
        }      

    }
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link href="style.css" rel="stylesheet" />
<title>Student_login</title>
<body>
	<div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="index.php" style="text-decoration: none;background-color: transparent; color:red;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
<h2>STUDENT LOGIN</h2>
<form action="student_login.php" method="post">
<div class="form-group">
<input class="form-control" placeholder="Student_id" name="id"  required>
</div>
<div class="form-group">
<input type="password" class="form-control" placeholder="Password" name="password" required>
</div>
<button type="submit" name="login">Login</button>
<button onclick="document.location='index.php'">Back to main page</button>
</form>
</div>
</div>
</div>

</body>
</html>
