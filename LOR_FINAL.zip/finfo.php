
<?php
session_start();
?><!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">




</head>
<body>

    <div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="faculty_home.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Home</a>
<a href="index.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>

</div>
</div>
<div id="page-wrapper">
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h1 class="page-head-line">&nbsp Faculty
</h1>
</div>
</div>
<link href="css/datatable/datatable.css" rel="stylesheet" />
<div class="panel panel-default">
<div class="panel-heading">
<p style="font-size: 15px;font-weight: bold;">Faculty Details</p>
</div>
<div class="panel-body">
<div class="table-sorting table-responsive">
<table class="table table-striped table-bordered table-hover" id="tSortable22">
<table class="table table-striped table-bordered table-hover" id="tSortable22">
<tbody>
<?php
 $id= $_SESSION["id"];
$db = mysqli_connect("localhost", "root", "", "proj");
if ($db->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{
$sql = "SELECT * FROM finfo where  fid like '%$id%' ";
$result = mysqli_query($db, $sql); 
}


while($row =mysqli_fetch_assoc($result)) 
{ 
  ?>

<thead>
<tr>
<tr>
<th>Name</th>
<td><?php echo $row['Name'];?></td>
</tr>
<tr>
<th>Faculty IDr</th>
<td><?php echo $row['fid'];?></td>
</tr>
<tr>
<th>Date of Birth</th>
<td><?php echo $row['DOB'];?></td>
</tr>
<tr>
<th>Gender</th>
<td><?php echo $row['Gender'];?></td>
</tr>
<tr>
<th>Branch</th>
<td><?php echo $row['Branch'];?></td>
</tr>


<tr>
<th>Cabin Number</th>
<td><?php echo $row['cno'];?></td>
</td>
</tr>

<tr>
<th>Contact Email</th>
<td><?php echo $row['Email'];?></td>
</td>
</tr>

</thead>

<?php
}$db -> close();
?>



</table>;



</thead>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</body>
</html>

