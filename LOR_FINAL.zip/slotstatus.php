<?php
session_start();
 $id= $_SESSION["id"];
$db = mysqli_connect("localhost", "root", "", "proj");
if ($db->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{
$sql = "SELECT * FROM lor where  Reg_no like '%$id%' ";
$result = mysqli_query($db, $sql); 

}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">


<style>
         .button {
         background-color: #1c87c9;
         border: none;
         color: white;
         padding: 10px 10px;
         text-align: center;
         text-decoration: none;
         display: inline-block;
         font-size: 10px;
         margin: 2px 2px;
         cursor: pointer;
         }
         section
{
    background-color:lightblue;
    width: 80%;
    margin-right:auto;
    margin-left:auto;
}
      </style>
</head>
<body>
<div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="student_home.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Home</a>

<a href="index.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>
<div id="page-wrapper">
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h1 class="page-head-line"><p style="text-align:center">LOR </p>
</h1>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<p style="font-size: 35px;font-weight: bold;">Lor Status</p>
<div class="panel-body">
<div class="table-sorting table-responsive">
<table class="table table-striped table-bordered" id="tSortable22">
<thead>
<tr>
<th>Faculty Id</th>
<th>Status</th>
<th>File</th>
</tr>
</thead>
</div>
</div>
</div>
<section  id="contact"> 
<form method="post" action="ulor.php" enctype="multipart/form-data" name="contactform" id="contactform" autocomplete="on"> 
<div align="center"> 
 
      
            <label for="file">Status of your Lor documents :</label>




            
            <?php
while($row =mysqli_fetch_assoc($result)) 
{ 
 

  echo ' <tr>'; 
  echo '<td>'.$row['fid'].'</td>'; 
  echo '<td>'.$row['status'].'</td>'; 
  echo '<td><a href="'.$row['Location'].'" class="button">Download Proof</a></td>';



      }?>
        


</div>
  
</form>            
</section> 
</body>
</html>


