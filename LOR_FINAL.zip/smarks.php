<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Academic Portal</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="js/jquery-1.10.2.js"></script>
</head>
<body>
<div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="student_home.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Home</a>

<a href="index.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>
<div id="page-wrapper">
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h1 class="page-head-line"><p style="text-align:center">MARKS</p></h1>
<div class="panel panel-default">
<div class="panel-heading">Internal Marks</div>
<div class="panel-body">
<div class="table-responsive">
<table id="sample_data" class="table table-bordered table-striped">
<thead>
<tr>

<th>S.no</th>
<th>Semester</th>

<th>Course id</th>
<th>CourseName</th>
<th>Cat1</th>
<th>cat2</th>
<th>DA</th>
<th>Quiz</th>
<th>Project review</th>
<th>FAT</th>
</tr>
</thead>
<tbody>
<td>1</td>
<td>Winter 2020-21</td>
<td>ITE1008</td>
<td>Open Source Programmig</td>
<td>28</td>
<td>25</td>
<td>9</td>
<td>10</td>
<td>90</td>
<td>84</td>
<tr>
<td>2</td>
<td>Winter 2020-21</td>
<td>ITE4001</td>
<td>Network and Information Security</td>
<td>24</td>
<td>27</td>
<td>8</td>
<td>9</td>
<td>78</td>
<td>80</td></tr>
<tr>
<td>3</td>
<td>Winter 2020-21</td>
<td>MAT3005</td>
<td>Applied Numerical Methods</td>
<td>21</td>
<td>25</td>
<td>10</td>
<td>9</td>
<td>83</td>
<td>100</td></tr>
</tbody>
</table>
</div>
</div>
</div>
</div>
<br />

</body>
</html>
