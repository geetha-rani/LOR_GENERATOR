
<?php

//' .$_GET['Reg_no'].'
require_once __DIR__ . '/vendor/autoload.php';

$mpdf = new \Mpdf\Mpdf();
$data='';
$data.='To,
<br/>
' .$_GET['college'].'
<br/><br/>
Dear Sir/Madam,
<br/>
It is with pleasure that I am writing this letter of recommendation for ' .$_GET['name'].' to support the  application for an MS ' .$_GET['college'].'. 
I have been teaching her for the past three years as a senior professor of the Computer Science Department at Vellore Institute Of Technology. 
Some of the subjects that I taught her are Networking, Data Structures, Algorithms, etc.
<br/><br/>
The first impressions that anyone forms of her are that of a person with outstanding technical knowledge and problem-solving skills.
' .$_GET['name'].' was an inquisitive student from the first year of the degree and asked a lot of questions.
 Assignments submitted by ' .$_GET['name'].' demonstrated her out of the box thinking and dedication towards the subject.
 <br/><br/>
 ' .$_GET['name'].' participated in all the seminars and olympiads organized by our university-related to computer science. 
 This kept her updated with the latest developments in this field. ' .$_GET['name'].' was also an active member of our university’s Computer Science Club.
 ' .$_GET['name'].' critical thinking ability and collaborative nature made her a favorite among students and professors.
 <br/><br/>
Based on the last 20 years of teaching experience, I would place ' .$_GET['name'].' among the top 10% of the students I have ever taught. I strongly recommend 
' .$_GET['name'].' to be considered as a potential student of MS in Computer Science at your university.
<br/><br/>
Regards,
<br/>
' .$_GET['fname'].'<br/>
Vellore Institute Of Technology';
$mpdf->WriteHTML($data);
$mpdf->Output('' .$_GET['Reg_no'].'.pdf','D');  
?>

