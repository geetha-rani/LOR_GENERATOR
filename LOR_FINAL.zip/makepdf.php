
<?php

//' .$_GET['Reg_no'].'
require_once __DIR__ . '/vendor/autoload.php';

$mpdf = new \Mpdf\Mpdf();
$data='';
$data.='To,
The Admission Committee,
I am pleased to write this letter of recommendation in favor of  ' .$_GET['name'].', who has recently applied
to ' .$_GET['college'].' for the Masters program. I have known' .$_GET['name'].' in the
capacity of being her Project Guide and have been acquainted with her for a good period, during which she has
proved to be diligent and adroit at performing research in her field.
Under my guidance, ' .$_GET['name'].' had developed a project on ‘Dissociative Electron Attachment for
n-Methyl Pyrrole’ and was highly appreciated for the data obtained for the SIMION 8.0 software where she simulated different trajectory
 particles in the designated setup. She was also praised for assisting one of the colleagues
from IISER Bhopal in sample testing the time of flight mass spectrometry. She later shifted to velocity map imaging
setup where she recovered useful feasible data of the sample after further processing and symmetrization.
Besides generating impressive data and simulation results, she was also commended for her sheer perseverance
throughout the project and her desire to learn, comprehend, and work on tasks independently. She got herself
acquainted with the complete apparatus thoroughly and executed tasks autonomously. She would not only
approach me for performance evaluation but would also acknowledge suggested amendments and rectifications.
Based on her project work,' .$_GET['name'].' had undertaken presentations on the ‘Time of Flight Mass
Spectrometer’, which was based on her initial understanding of the project after a brief read-through of the
research paper and on ‘Dissociative Electron Attachment for n-Methyl Pyrrole’, which was the final presentation
demonstrated after the accomplishment of the project in the presence of an external examiner and myself. She
displayed informative presentations in an appealing way which showed her strong prospect in the domain. She
secured good scores in her lab work during the development phase of the project by working extra hours and
operating the apparatus along with the assistance of a postdoctoral fellow.
' .$_GET['name'].' had been an industrious and ebullient student who has a great penchant towards acquiring advanced
 and extensive erudition. She indulged in assignments with an optimistic attitude and embraced
constructive criticisms in order to precipitate a flawless performance. She possesses requisite knowledge in her
domain and despite shortcomings, she strives to reach excellence by constantly struggling to ameliorate herself.
Having observed ' .$_GET['name'].' discharge her duties from close quarters, I can ensure that her remarkable attributes
 will stand her in a good stead over the course of the intense Doctorate program. Her indefatigable
drive to flourish coupled with domain expertise will empower her to meet the high standards set by your university.
Hence, I am confident that' .$_GET['name'].' will be a phenomenal addition to your university’s academic
community and grant her my strongest recommendation.<br/><br/>
Sincerely,<br/>
Dr. <REFEREE NAME>
--XYZ--<br/>
Department of --XYZ--<br/>
Vellore Institute of techonology';
$mpdf->WriteHTML($data);
$mpdf->Output('myfile.pdf','D');  
?>

<!DOCTYPE html>
<html>
<head>
<title>PS Bank</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
  <body>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">


 
</head>
<body>
<div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="student_home.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Home</a>

<a href="index.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>
<div id="page-wrapper">
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h1 class="page-head-line"><p style="text-align:center">LOR Acceptance</p>
</h1>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<p style="font-size: 15px;font-weight: bold;">Lor process</p>
</div>
</div>
</div>
</div>
</div>
</div>

  </body>
</body>
</html>



