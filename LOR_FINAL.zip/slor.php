
<?php
session_start();
$id="";
$password="";
$errors =array();
$db=mysqli_connect('localhost','root','','proj') or die('could not connect to database');


if(isset($_POST['submit'])){

	/*. */

	$name=$_POST['name'];
	$email=$_POST['email'];
	$Reg_no=$_POST['Reg_no'];
	$Faculty=$_POST['Faculty'];
	$college=$_POST['college'];
	$comments=$_POST['comments'];
	$fname=$_POST['fname'];
	$suggestion=$_POST['suggestion'];
	$target_dir= "myfile/";
	$target_file = $target_dir.date("dmYhis"). basename($_FILES["file"]["name"]);
	$uploadOk = 1;
	$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
	if($imageFileType != "jpg" || $imageFileType != "png" ||
	 $imageFileType != "jpeg" || $imageFileType !="gif" ){
	if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
		$files=date("dmYhis"). basename($_FILES["file"]["name"]);
	}
		else{echo "Error Uploading File";
			exit; 
}
		
 $location = "myfile/".$files;
	$sql="INSERT INTO slor(name,email,Reg_no,Faculty,college,comments,suggestion,Location,fname) VALUES('$name','$email','$Reg_no','$Faculty','$college','$comments','$suggestion','$location','$fname')";
 $result=mysqli_query($db,$sql);
	if($result){
 echo "Your Request processed sucessfully";
header("refresh:1;url=student_home.php");
    }
    else{
        echo "Please try again";
    }
}  }   
?>
<!DOCTYPE html>
<html>
<head>
<title>PS Bank</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
  <body>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">

<style type="text/css">

@import url('https://fonts.googleapis.com/css?family=Montserrat:600|Open+Sans:600&display=swap');
*{
margin: 0;
padding: 0;
text-decoration: none;

}
html, body { border: 0; margin: 0; padding: 0; }
body { font: 62.5% "Lucida Grande", "Lucida Sans Unicode", Arial, sans-serif; min-width: 100%; min-height: 101%; color: #666; background:#eee; }

/* END Remove This */

#contact p, label, legend { font: 1.5em "Lucida Grande", "Lucida Sans Unicode", Arial, sans-serif; }

#contact h1 { margin: 10px 0 10px; font-size: 24px; color: #333333; }
#contact hr { color: inherit; height: 0; margin: 6px 0 6px 0; padding: 0; border: 1px solid #d9d9d9; border-style: none none solid; }

#contact { 
	display: block; 
	width: 850px; 
	margin: 50px auto; 
	padding: 40px; 
	border: 10px solid #cbcbcb; 
	background-color: #FFF; 
	
	-webkit-border-radius:5px; 
	-moz-border-radius:5px; 
	border-radius:5px; 
	
	box-shadow: 0 2px 5px rgba(50, 50, 50, 0.1);
	-webkit-box-shadow: 0 2px 5px rgba(50, 50, 50, 0.1);
	-moz-box-shadow: 0 2px 5px rgba(50, 50, 50, 0.1);
}

/* Form style */

mark.validate {
	display: inline-block;
	margin: 12px 0 0 10px;
	width: 16px;
	height: 16px;
	background: transparent none;
}
mark.valid {
	background: url(../assets/success.gif) no-repeat top left;
}
mark.error {
	background: url(../assets/error.gif) no-repeat top left;
}

#contact label { 
	display: inline-block; 
	float: left; 
	height: 1em; 
	line-height: 1em; 
	padding: 6px 0 0;
	width: 155px; 
	font-size: 1.4em; 
	margin: 5px 0; 
	clear: both;	
}

#contact label small {
	font-size: 0.75em;
	color: #ccc;
}

#contact label.verify {
	padding: 0;
	margin: 2px 10px 2px 0;
	width: 145px; 
	text-align: right;
}
#contact label.verify img {
	padding:1px; 
	border:1px solid #cccccc;
	-webkit-border-radius:3px; 
	-moz-border-radius:3px; 
	border-radius:3px; 
}

#contact input, #contact textarea, #contact select { 
	width: 220px; 
	padding: 5px; 
	color: #666; 
	background: #f5f5f5; 
	border: 1px solid #ccc; 
	margin: 5px 0; 
	font:1.4em "Lucida Grande", "Lucida Sans Unicode", Arial, sans-serif; 
	-webkit-border-radius:5px; 
	-moz-border-radius:5px; 
	border-radius:5px; 
	vertical-align: top;
	
	transition: all 0.25s ease-in-out; 
	-webkit-transition: all 0.25s ease-in-out; 
	-moz-transition: all 0.25s ease-in-out; 
	
	box-shadow: 0 0 5px rgba(81, 203, 238, 0); 
	-webkit-box-shadow: 0 0 5px rgba(81, 203, 238, 0); 
	-moz-box-shadow: 0 0 5px rgba(81, 203, 238, 0); 
} 
#contact select {
	width: 232px; 
	margin: 8px 0;
}
#contact input#verify {
	width: 55px;
}
#contact textarea { 
	width: 414px; 
}
#contact input:focus, #contact textarea:focus, #contact select:focus { 
	border: 1px solid #ddd; 
	background-color: #fff; 
	color:#333; 
	outline: none;
	position: relative;
	z-index: 5;
	
	box-shadow: 0 0 5px rgba(81, 203, 238, 1);
	-webkit-box-shadow: 0 0 5px rgba(81, 203, 238, 1);
	-moz-box-shadow: 0 0 5px rgba(81, 203, 238, 1);
	
	-webkit-transform: scale(1.05);
	-moz-transform: scale(1.05);
	
	transition: all 0.25s ease-in-out; 
	-webkit-transition: all 0.25s ease-in-out; 
	-moz-transition: all 0.25s ease-in-out; 
}
#contact input.error, #contact textarea.error, #contact select.error {
	box-shadow: 0 0 5px rgba(204, 0, 0, 0.5);
	-webkit-box-shadow: 0 0 5px rgba(204, 0, 0, 0.5);
	-moz-box-shadow: 0 0 5px rgba(204, 0, 0, 0.5);
	border: 1px solid #faabab;
	background: #fef3f3
}
#contact input.submit { 
	width: auto; 
	cursor: pointer; 
	position: relative;
	border: 1px solid #282828; 
	color:#fff; 
	padding: 6px 16px;
	text-decoration: none;
	font-size: 1.5em;
	
	background:#555; 
	
	background:-webkit-gradient(
	    linear,
	    left bottom,
    	left top,
	    color-stop(0.12, rgb(60,60,60)),
	    color-stop(1, rgb(85,85,85))
	);
	background:-moz-linear-gradient(
	    center bottom,
	    rgb(60,60,60) 12%,
    	rgb(85,85,85) 100%
	);
	
	box-shadow: 0 2px 3px rgba(0,0,0,0.25);
	-moz-box-shadow: 0 1px 3px rgba(0,0,0,0.25);
	-webkit-box-shadow: 0 1px 3px rgba(0,0,0,0.25);
	
	text-shadow: 0 -1px 1px rgba(0,0,0,0.25);
}
#contact input.submit:hover { 
	background: #282828 !important; 
	transition: none;
	-webkit-transition: none;
	-moz-transition: none; 
}
#contact input.submit:active, #contact input.submit:focus { 
	top: 1px; 
}



#contact input[type="submit"][disabled] { background:#888; }
#contact fieldset { padding:20px; border:1px solid #eee; -webkit-border-radius:5px; -moz-border-radius:5px; margin:0 0 20px; }
#contact legend { padding:7px 10px; font-weight:bold; color:#000; border:1px solid #eee; -webkit-border-radius:5px; -moz-border-radius:5px; margin-bottom:0 !important; margin-bottom:20px; }

#contact span.required{ font-size: 13px; color: #ff0000; } /* Select the colour of the * if the field is required. */

#message { margin: 1em 0; padding: 0; display: block; background: transparent none; }

.error_message { display: block; height: 22px; line-height: 22px; background: #FBE3E4 src('error.gif') no-repeat 10px center; padding: 3px 10px 3px 35px; color:#8a1f11;border: 1px solid #FBC2C4; -webkit-border-radius:5px; }

.loader { padding: 0 10px; }

#contact #success_page h1 { background: src('success.gif') left no-repeat; padding-left:22px; }

acronym { border-bottom:1px dotted #ccc; }
</style> 
 

 
</head>
<body>

    <div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="student_home.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Home</a>

<a href="index.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>

<section id="contact"> 
	
    <header> 
    
        <h1>LOR application</h1> 
  
        
    </header> 
    
    <mark id="message"></mark> 
             
    <form method="post" action="slor.php" enctype="multipart/form-data" name="contactform" id="contactform" autocomplete="on"> 

        <fieldset> 
                
            <legend>LOR application</legend> 
            
            <div> 
                <label for="name" >Your Name</label> 
                <input name="name" type="text" id="name" placeholder="Enter your name" required="required" /> 
            </div> 
			 
            <div> 
                <label for="email">Email</label> 
                <input name="email" type="email" id="email" placeholder="Enter your Email Address" pattern="^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$" required="required" /> 
            </div>	            			
            
            <div> 
                <label for="Reg_no" >Reg No <small></small></label> 
                <input name="Reg_no" type="text" id="Reg_no" size="30" placeholder="Enter your Reg number" /> 
            </div> 
            <div> 
                <label for="Faculty" >Faculty Id <small></small></label> 
                <input name="Faculty" type="text" id="Faculty" size="30" placeholder="Faculty you are applying for" /> 
            </div> 
			<div> 
                <label for="fname" >Faculty name<small></small></label> 
                <input name="fname" type="text" id="fname" size="30" placeholder="Faculty name" /> 
            </div> 
            <div> 
                <label for="website" >Mobile no <small>(optional)</small></label> 
                <input name="website" type="tell" id="phone" placeholder="Enter your mobile number" /> 
            </div> 
            
        </fieldset> 
        
        <fieldset> 
                
            <legend>Univeristy Details</legend> 
            
            <div> 
			<label for="comments">College Applied for </label> 
                <textarea name="college" cols="4" rows="1"  id="comments" placeholder="Enter your comments" spellcheck="true" required="required"></textarea> > 
            </div>
            <div> 
                <label for="comments">Your Preferences and achievements </label> 
                <textarea name="comments" cols="40" rows="3"  id="comments" placeholder="Enter your Achivements properly typed" spellcheck="true" required="required"></textarea> 
            </div> 	
            
            <div> 
                <label for="comments">Suggestions </label> 
                <textarea name="suggestion" cols="40" rows="3"  id="comments" placeholder="Enter your comments" spellcheck="true" required="required"></textarea> 
            </div> 
            
         
        
            <label for="file">Upload your relevant documents :</label>
            <input type="file" id="file" name="file" >
         
        
 
</fieldset>
<button>  
 <input name="submit" type="submit" value="Submit">           
</button>

<br>
        <br>
        
    </form> 
                
</section> 
   

  </body>
</body>
</html>


