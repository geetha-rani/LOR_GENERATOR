
<?php
session_start();
$id="";
$password="";
$errors =array();
$db=mysqli_connect('localhost','root','','proj') or die('could not connect to database');
$Reg_no = $_GET['Reg_no']; 
$fname = $_GET['fname']; 


	$status="Rejected";
  
  $query="update  lor  set `status`='$status' where Reg_no = '$Reg_no' and f_name='$fname'";
$del = mysqli_query($db,$query,); // delete query
if($del)
{
  echo "Accepted";
    mysqli_close($db); // Close connection
    header("location:flor.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error"; // display error message if not delete
}
?>

