<?php
session_start();
?><!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">
<?php
 $id= $_SESSION["id"];
 $db = mysqli_connect("localhost", "root", "", "proj");
 if(isset($_POST['submit'])){

  $currentPassword=$_POST['currentPassword'];
  $newPassword=$_POST['newPassword'];
  $confirmPassword=$_POST['confirmPassword'];

if ($db->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{

  $query="SELECT * FROM user WHERE id='$id'";


$result = mysqli_query($db,$query);
while($row=mysqli_fetch_array($result)){
$password=$row["password"];
if($currentPassword==$password){
  if($newPassword==$confirmPassword){
    $q="UPDATE user SET password='$confirmPassword' WHERE id='$id'";
$update=mysqli_query($db,$q);
 if($update){
  echo "<script>alert('Successfully changed')</script>";

 }

  }else{
    echo "<script>alert('new and confirm password do not match')</script>";
   }
   

}else{
  echo "<script>alert('new and old password do not match')</script>";
 }



}
}}
?>

</style>
</head>
<body>
<div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="student_home.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Home</a>

<a href="index.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>
<div id="page-wrapper">
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h1 class="page-head-line"><p style="text-align:center">Services</p>
</h1>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<p style="font-size: 15px;font-weight: bold;">Password Change</p>
</div>
<div class="container">
<div class="row">
<div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
<form method="post" action="" align="center">
Current Password:<br>
<input type="password" name="currentPassword"><span id="currentPassword" class="required"></span>
<br>
New Password:<br>
<input type="password" name="newPassword"><span id="newPassword" class="required"></span>
<br>
Confirm Password:<br>
<input type="password" name="confirmPassword"><span id="confirmPassword" class="required"></span>
<br><br>
<input type="submit" name="submit" value="SUBMIT">
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</body>
</html>