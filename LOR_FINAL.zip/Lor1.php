
<?php

//' .$_GET['Reg_no'].'
require_once __DIR__ . '/vendor/autoload.php';

$mpdf = new \Mpdf\Mpdf();
$data='';
$data.='This is a letter of recommendation by ' .$_GET['fname'].' for a student aspiring to pursue a Masters in ' .$_GET['college'].'.
<br/><br/>
It is with pleasure that I am writing this letter of recommendation for ' .$_GET['name'].' in support of  application to pursue a Masters degree at ' .$_GET['college'].'.
 I have known her for the past three years in my capacity as the senior
  professor at Vellore Institute Of Technology.
 <br/><br/>
During the course of ' .$_GET['name'].' studies, ' .$_GET['name'].' came across as a sincere and hardworking student. 
This was evident from the effort that she put into her term work assignments. <br/>
' .$_GET['name'].' has been forthcoming with answers to questions raised by me during the lecture sessions and I 
have found her be to an active participant in classroom discussions. ' .$_GET['name'].' is a lively, modest,
 and honest student who is well mannered and respects her peers and professors alike.
 <br/><br/>
' .$_GET['name'].' has the ability to understand the presented concepts very quickly and to think clearly,
 which coupled with her hard work has helped her to perform consistently well in her University examinations. 
 <br/><br/>
 ' .$_GET['name'].' top grades in academics reflect her exceptional intellectual abilities. In addition to this, 
the student possesses a firm and well-rounded knowledge of various software programming languages like C, C++, Java, HTML, SQL.
<br/><br/>
Apart from academics, ' .$_GET['name'].' was very proactive in most of the institutes’ activities. ' .$_GET['name'].' has been an active member of the Students’ Council
 for 2 years – the main student body of our college. She was the treasurer of the SC 2010-11. ' .$_GET['name'].' organized and managed ABHYANTRIKI-our annual technical festival and SYMPHONY-the annual cultural festival.
 <br/><br/>
I am of the view that ' .$_GET['name'].' will be a worthy student at your esteemed university, which will be the ideal place for her to improve upon  existing skills by pursuing a Masters program.
' .$_GET['name'].' pragmatic analysis and acumen will help  accomplish  goals.<br/><br/> Hence, I strongly recommend ' .$_GET['name'].' to be considered as
 a potential candidate for admission into your esteemed university with matching financial aid.
<br/><br/>
Regards,<br/>
Prof. ' .$_GET['fname'].'<br/>
Vellore Institute Of Technology';
$mpdf->WriteHTML($data);
$mpdf->Output('' .$_GET['Reg_no'].'.pdf','D');  
?>


