
<?php
session_start();
$id="";
$password="";
$errors =array();
$db=mysqli_connect('localhost','root','','proj') or die('could not connect to database');
$Reg_no = $_GET['Reg_no']; 
$fname = $_GET['fname']; 
$del = mysqli_query($db,"delete from slor where Reg_no = '$Reg_no' and fname='$fname'"); // delete query
if($del)
{
    mysqli_close($db); // Close connection
    header("location:flor.php"); // redirects to all records page
    exit;	
}
else
{
    echo "Error deleting record"; // display error message if not delete
}
?>