
<?php
session_start();
?><!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="style.css">


</style>
</head>
<body>
<div class="header">

<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="student_home.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Home</a>

<a href="index.php" style="text-decoration: none;background-color: transparent; color:#ededed;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>
<div id="page-wrapper">
<div id="page-inner">
<div class="row">
<div class="col-md-12">
<h1 class="page-head-line"><p style="text-align:center">COURSE COMPLETED</p>
</h1>
</div>
</div>
<div class="panel panel-default">
<div class="panel-heading">
<p style="font-size: 15px;font-weight: bold;">Academic Courses</p>
</div>
<div class="panel-body">
<div class="table-sorting table-responsive">
<div class="panel-body">
<table class="table table-striped table-bordered table-hover" id="tSortable22">
<thead>
<tr>
<th>S.no</th>
<th>Semester</th>
<th>Course id</th>
<th>Course Name</th>
<th>Slot</th>
</tr>
</thead>
<?php
 $id= $_SESSION["id"];
$db = mysqli_connect("localhost", "root", "", "proj");
if ($db->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
else{
$sql = "SELECT * FROM scourses where  regno like '%$id%' ";
$result = mysqli_query($db, $sql); 



while($row =mysqli_fetch_assoc($result)) 
{ 
  ?>
<tbody>
<tr>
<td><?php echo $row['sno'];?></td>
<td><?php echo $row['semester'];?></td>
<td><?php echo $row['courseid'];?></td>
<td><?php echo $row['coursename'];?></td>
<td><?php echo $row['slot'];?></td>
</tr>
</tbody>
<?php
}}
?>


</table>;
</tbody>
</table>





</div>
</div>
</div>
</div>
</div>
</body>
</html>


