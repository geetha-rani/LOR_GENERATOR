<?php
session_start();
$id="";
$password="";
$error = '';
$db=mysqli_connect('localhost','root','','proj') or die('could not connect to database');
//Login user
if(isset($_POST['login'])){
    $id=mysqli_real_escape_string($db,$_POST['id']);
    $password=mysqli_real_escape_string($db,$_POST['password']);
    if($id=='' || $password=='')
{
$error='All fields are required';
}
        $query="SELECT * FROM user WHERE id='$id' AND password='$password'";
        $results=mysqli_query($db,$query);
        if(mysqli_num_rows($results)){
            $_SESSION["id"]=$id;
			$_SESSION["password"]=$password;
            $_SESSION["type"]=$type;
        header("location:faculty_home.php");} 
        else{

            $error='Please try again with correct credentials';
        }      

    
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
<!-- CSS only -->
<link href="style.css" rel="stylesheet" />
<title>faculty_login</title>
<body>
	<div class="header">
<div class="logo">
VITIANS LOGIN PORTAL
</div>
<div class="sub">
<a href="index.php" style="text-decoration: none;background-color: transparent; color:red;"><span class = "glyphicon glyphicon-log-in"></span> Logout</a>
</div>
</div>
<div class="container">
<div class="row">
<div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
<h2>Faculty LOGIN</h2>
<form action="faculty_login.php" method="post">
<?php
if($error!='')
{
echo '<h5 class="text-danger text-center">'.$error.'</h5>';
}
?>
<div class="form-group">
<input class="form-control" placeholder="faculty_id" name="id"  required>
</div>
<div class="form-group">
<input type="password" class="form-control" placeholder="Password" name="password" required>
</div>
<!-- 

<div class="form-group">
<label for="userType">Role:</label>
<input type="radio" name="userType" value="student"
class="custom-radio" required>&nbsp;Student
<input type="radio" name="userType" value="faculty"
class="custom-radio" required>&nbsp;Faculty
</div>
-->
<button type="submit" name="login">Login</button>
<button onclick="document.location='index.php'">Back to main page</button>
</form>
</div>
</div>
</div>
</body>
</html>
/