
<?php

//' .$_GET['Reg_no'].'
require_once __DIR__ . '/vendor/autoload.php';

$mpdf = new \Mpdf\Mpdf();
$data='';
$data.='To,
<br/>
' .$_GET['name'].'
<br/><br/>
Dear ' .$_GET['name'].',
<br/>
Your details are not properly orderd, please check again with that and apply again,


<br/><br/>
Regards,
<br/>
' .$_GET['fname'].'<br/>
Vellore Institute Of Technology';
$mpdf->WriteHTML($data);
$mpdf->Output('' .$_GET['Reg_no'].'.pdf','D');  
?>

